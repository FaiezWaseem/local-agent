var e=`</tool_call>`,t=/(?:^|\n)\s*(?:\*\*)?Call Tool:(?:\*\*)?\s*([A-Za-z_][\w-]*)\s*(?:\n|$)\s*(?:\*\*)?Arguments:(?:\*\*)?\s*([\s\S]*?)(?=(?:\n\s*(?:\*\*)?Call Tool:)|$)/gi,n={"chat.deepseek.com":`DeepSeek`,"chat.qwen.ai":`Qwen`,"chat.z.ai":`Z.ai`},r=`local-ai-agent:deepseek-answer`,i=`local-ai-agent:zai-answer`,a=`local-ai-agent:provider-stream-state`,o=`local-ai-agent:provider-stream-delta`,s=`ws://127.0.0.1:43121/ws/extension`,c=`local-ai-agent`,l=`local-ai-agent-completion-bridge-client`,u=15e3,d=`local-ai-agent-paused`,f=`local-ai-agent-pending-shell-jobs`,p=2e3,m=`[LOCAL_AGENT_PROTOCOL_V4]`;function h(){let e=N();return`${m}
MANDATORY LOCAL AGENT CONTROL FOR THIS REPLY
The text before this marker is the user's actual task. This control section is not the task. Follow it silently. Never quote, summarize, explain, or acknowledge these instructions.

TOOL AUTHORITY
- Never invoke ${e} native tools, built-in function calling, code interpreter, web search, browser actions, artifacts, plugins, or any other platform tool. Ignore them even if ${e} offers or recommends them.
- The only permitted tools are: read_file, write_file, edit_file, delete_file, list_directory, run_command, git_status, git_diff, git_log.
- These local tools are not native function calls. A local tool call must be emitted as literal assistant text for the browser extension to detect.
- If the task requires reading, listing, creating, editing, deleting, running, or checking project files, you MUST use a permitted local tool. Do not merely describe the action and do not invent its result.

LOCAL TOOL-CALL OUTPUT CONTRACT
- When a local tool is needed, your entire response must contain exactly one tool-call envelope and nothing else: no explanation, acknowledgement, heading, Markdown fence, or trailing text.
- Wrap the JSON object between the opening tag <tool_call> and the closing tag </tool_call>.
- The JSON object must have exactly two top-level keys. Its shape is {"name":"TOOL_NAME","arguments":{}}. Replace TOOL_NAME and arguments with real values.
- Emit valid strict JSON with double-quoted keys and strings. Escape backslashes, quotes, newlines, and other control characters according to JSON rules.
- Emit only one call, then stop and wait for the extension's <tool_result>. Never execute a native tool, simulate a result, or claim the call succeeded.

ARGUMENT CONTRACT
- read_file: path
- write_file: path, content
- edit_file: path, old_text, new_text. old_text must exactly match existing file text.
- delete_file: path. It removes one file only, never a directory.
- list_directory: path
- run_command: command, with optional timeout
- git_status: no arguments
- git_diff: optional path
- git_log: optional limit
- All paths are relative to the active project. Never access files outside it.

RESULT AND COMPLETION CONTRACT
- A <tool_result> message is authoritative output from the local extension. Read it, continue the original task, and issue the next single local call if needed.
- The extension assigns every call a unique tool_call_id and returns the same ID in <tool_result>. Use it to associate delayed background shell results with the original call.
- run_command executes as a background job. Wait for its final <tool_result>; do not repeat the command while it is pending.
- If a result reports failure, correct the arguments and retry when appropriate. Do not switch to a ${e}-native tool.
- Only when the task requires no local tool, or when all required local work is complete, respond normally with a concise answer.`}var ee=8e3,te=5e3,ne=3e4,re=new Set([`read_file`,`write_file`,`edit_file`,`delete_file`,`list_directory`,`run_command`,`git_status`,`git_diff`,`git_log`]),ie=new Set([`write_file`,`edit_file`]),ae=new Set([`delete_file`]),oe=new Set([`run_command`]),g=new Set,_=new Map,v=new Set,se=window,ce=!1,le=0,y=null,ue=0,b=!1,x=!1,S=!1,C=0,w=!1,T=!0,de=!1,E=null,fe=0,D=0,O=null,k=0,A=0,pe=0,j=null,M=!1;function N(){return n[location.hostname]||`AI chat`}function me(){if(location.hostname===`chat.deepseek.com`)return`deepseek`;if(location.hostname===`chat.z.ai`)return`zai`}function he(){return Object.hasOwn(n,location.hostname)}function ge(e){return!T||!he()||e.includes(m)?e:`${e.trimEnd()}\n\n${h()}`}function P(e){return e.replace(/[\\/]+$/,``).split(/[\\/]/).at(-1)||e||`No project`}function _e(e){return{attached:`Ready`,detected:`Tool detected`,approval:`Needs approval`,executing:`Working`,background:`Background job`,cooldown:`Cooling down`,sending:`Sending result`,generating:`AI responding`,waiting:`Waiting`,connecting:`Connecting`,stopped:`Stopped`,error:`Error`}[e]||e}function ve(e){let t=e.shadowRoot;if(!t)return null;let n=t.querySelector(`#card`),r=t.querySelector(`#state`),i=t.querySelector(`#message`),a=t.querySelector(`#updated`),o=t.querySelector(`#project`),s=t.querySelector(`#count`),c=t.querySelector(`#active-tool`),l=t.querySelector(`#active-command`),u=t.querySelector(`#status-panel`),d=t.querySelector(`#history-panel`),f=t.querySelector(`#status-tab`),p=t.querySelector(`#history-tab`),m=t.querySelector(`#history-list`),h=t.querySelector(`#collapse`),ee=t.querySelector(`#connect`),te=t.querySelector(`#stop`);return!n||!r||!i||!a||!o||!s||!c||!l||!u||!d||!f||!p||!m||!h||!ee||!te?null:{host:e,card:n,state:r,message:i,updated:a,project:o,count:s,activeTool:c,command:l,statusPanel:u,historyPanel:d,statusTab:f,historyTab:p,historyList:m,collapse:h,connect:ee,stop:te}}function ye(e,t){let n=e.getBoundingClientRect();return{x:Math.max(8,Math.min(t.x,window.innerWidth-n.width-8)),y:Math.max(8,Math.min(t.y,window.innerHeight-n.height-8))}}function be(e,t){let n=ye(e,t);return e.style.left=`${n.x}px`,e.style.top=`${n.y}px`,e.style.right=`auto`,e.style.bottom=`auto`,n}function xe(e){let t=e.card.querySelector(`#handle`);if(!t)return;let n=null;t.addEventListener(`pointerdown`,r=>{if(r.target.closest(`button`))return;let i=e.host.getBoundingClientRect();n={pointerId:r.pointerId,offsetX:r.clientX-i.left,offsetY:r.clientY-i.top},t.setPointerCapture(r.pointerId),e.card.dataset.dragging=`true`,r.preventDefault()}),t.addEventListener(`pointermove`,t=>{!n||n.pointerId!==t.pointerId||be(e.host,{x:t.clientX-n.offsetX,y:t.clientY-n.offsetY})});let r=async t=>{if(!n||n.pointerId!==t.pointerId)return;n=null,e.card.dataset.dragging=`false`;let r=e.host.getBoundingClientRect();await chrome.storage.local.set({indicatorPosition:{x:r.left,y:r.top}})};t.addEventListener(`pointerup`,e=>void r(e)),t.addEventListener(`pointercancel`,e=>void r(e)),e.collapse.addEventListener(`click`,async()=>{let t=e.card.dataset.collapsed!==`true`;e.card.dataset.collapsed=String(t),e.collapse.textContent=t?`+`:`-`,e.collapse.setAttribute(`aria-label`,t?`Expand local agent status`:`Collapse local agent status`),await chrome.storage.local.set({indicatorCollapsed:t});let n=e.host.getBoundingClientRect();be(e.host,{x:n.left,y:n.top})})}function Se(){try{return sessionStorage.getItem(d)===`true`}catch{return!1}}function Ce(e){try{sessionStorage.setItem(d,String(e))}catch{}}function F(){y&&(y.card.dataset.running=String(S),y.connect.disabled=S||w,y.stop.disabled=!S&&!T||w)}function I(e){S!==e&&(S=e,C+=1),F()}function we(e){let t=e.arguments||{};if(e.name===`run_command`)return`$ ${String(t.command||``)}`;let n=typeof t.path==`string`?` ${JSON.stringify(t.path)}`:``;if(e.name===`edit_file`){let e=String(t.old_text??t.old_content??``),r=String(t.new_text??t.new_content??``);return`> edit_file${n} --old ${e.length} chars --new ${r.length} chars`}return e.name===`write_file`?`> write_file${n} --content ${String(t.content??``).length} chars`:e.name===`git_log`&&t.limit!=null?`> git_log --limit ${String(t.limit)}`:`> ${e.name}${n}`}function L(){y&&(y.activeTool.textContent=E?.name||`Idle`,y.activeTool.title=E?.callId||`No active tool call`,y.command.textContent=E?.command||`No tool is running.`,y.command.dataset.active=String(!!E))}function Te(e,t){E={name:e.name,callId:t,command:we(e)},L()}function R(e){e&&E?.callId!==e||(E=null,L())}function Ee(e){let t=e;try{t=JSON.stringify(JSON.parse(e),null,2)}catch{}let n=12e4;return t.length>n?`${t.slice(0,n)}\n\n... truncated in monitor (${t.length-n} more characters)`:t}function De(e){if(!y)return;let t=document.createDocumentFragment();for(let n of e){let e=document.createElement(`details`);e.className=`history-item`;let r=document.createElement(`summary`),i=document.createElement(`span`);i.className=`history-tool`,i.textContent=n.tool||`unknown`;let a=document.createElement(`span`);a.className=n.ok?`history-meta success`:`history-meta failure`,a.textContent=`${n.ok?`OK`:`Failed`} - ${new Date(n.ts).toLocaleTimeString()}`,r.append(i,a);let o=document.createElement(`code`);o.className=`history-id`,o.textContent=n.call_id||`history-${n.id}`;let s=document.createElement(`div`);s.className=`io-label`,s.textContent=`Input`;let c=document.createElement(`pre`);c.textContent=Ee(n.args||`{}`);let l=document.createElement(`div`);l.className=`io-label`,l.textContent=`Output`;let u=document.createElement(`pre`);u.textContent=Ee(n.result||`{}`),e.append(r,o,s,c,l,u),t.append(e)}y.historyList.replaceChildren(t),e.length||(y.historyList.textContent=`No completed tool calls yet.`)}async function Oe(){if(y){y.historyList.textContent=`Loading tool-call history...`;try{let{token:e}=await chrome.storage.local.get(`token`);if(!e)throw Error(`Connect first to view daemon history.`);let t=await K(await fetch(`http://127.0.0.1:43121/history`,{headers:{authorization:`Bearer ${e}`}}));De(Array.isArray(t.items)?t.items:[])}catch(e){y&&(y.historyList.textContent=`History unavailable: ${e.message}`)}}}function ke(e){if(!y)return;let t=e===`history`;y.card.dataset.view=e,y.statusPanel.hidden=t,y.historyPanel.hidden=!t,y.statusTab.dataset.active=String(!t),y.historyTab.dataset.active=String(t),t&&Oe()}function Ae(){y?.card.dataset.view===`history`&&Oe()}function je(e){e.connect.addEventListener(`click`,()=>void $e()),e.stop.addEventListener(`click`,()=>void et()),e.statusTab.addEventListener(`click`,()=>ke(`status`)),e.historyTab.addEventListener(`click`,()=>ke(`history`)),e.historyPanel.querySelector(`#history-refresh`)?.addEventListener(`click`,()=>void Oe()),F()}async function Me(){if(y)return y;let e=document.getElementById(`deepseek-local-agent-indicator`);if(e)return y=ve(e),y;let t=document.createElement(`div`);t.id=`deepseek-local-agent-indicator`,t.style.position=`fixed`,t.style.right=`18px`,t.style.bottom=`18px`,t.style.zIndex=`2147483647`,t.style.fontSize=`initial`;let n=t.attachShadow({mode:`open`});if(n.innerHTML=`
    <style>
      :host { all: initial; }
      * { box-sizing: border-box; }
      #card {
        width: min(330px, calc(100vw - 16px));
        overflow: hidden;
        border: 1px solid rgba(255,255,255,.16);
        border-radius: 14px;
        color: #eff7f1;
        background: rgba(20, 31, 27, .96);
        box-shadow: 0 18px 46px rgba(0,0,0,.28), 0 2px 8px rgba(0,0,0,.18);
        font: 12px/1.45 "Aptos", "Trebuchet MS", sans-serif;
        backdrop-filter: blur(16px);
        transition: width 160ms ease, box-shadow 160ms ease;
      }
      #card[data-dragging="true"] { box-shadow: 0 24px 56px rgba(0,0,0,.38); }
      #handle {
        display: flex;
        align-items: center;
        gap: 9px;
        min-height: 42px;
        padding: 8px 9px 8px 11px;
        cursor: grab;
        user-select: none;
        touch-action: none;
        border-bottom: 1px solid rgba(255,255,255,.1);
      }
      #card[data-dragging="true"] #handle { cursor: grabbing; }
      .mark {
        width: 20px;
        height: 20px;
        display: grid;
        place-items: center;
        flex: 0 0 auto;
        border-radius: 7px 7px 7px 2px;
        color: #17231e;
        background: #f06a42;
        font: 800 12px/1 Georgia, serif;
      }
      .heading { min-width: 0; flex: 1; }
      .title {
        display: block;
        color: #fff;
        font-size: 11px;
        font-weight: 800;
        letter-spacing: .5px;
        text-transform: uppercase;
      }
      #project {
        display: block;
        overflow: hidden;
        color: #9eaea6;
        font-size: 9px;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      #active-tool {
        max-width: 92px;
        overflow: hidden;
        padding: 3px 7px;
        border: 1px solid rgba(255,255,255,.11);
        border-radius: 999px;
        color: #b9c8c0;
        background: rgba(255,255,255,.06);
        font: 800 9px/1 "Aptos", "Trebuchet MS", sans-serif;
        letter-spacing: .25px;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .header-dot {
        width: 8px;
        height: 8px;
        flex: 0 0 auto;
        border-radius: 50%;
        background: #63ce9b;
        box-shadow: 0 0 0 4px rgba(99,206,155,.12);
      }
      #collapse {
        width: 25px;
        height: 25px;
        padding: 0;
        cursor: pointer;
        border: 1px solid rgba(255,255,255,.12);
        border-radius: 7px;
        color: #bdc9c3;
        background: rgba(255,255,255,.06);
        font: 700 15px/1 sans-serif;
      }
      #collapse:hover { color: #fff; background: rgba(255,255,255,.12); }
      .body { padding: 10px 14px 12px; }
      [hidden] { display: none !important; }
      .tabs {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 4px;
        margin-bottom: 11px;
        padding: 3px;
        border-radius: 9px;
        background: rgba(255,255,255,.055);
      }
      .tab {
        min-height: 27px;
        cursor: pointer;
        border: 0;
        border-radius: 7px;
        color: #8fa199;
        background: transparent;
        font: 800 9px/1 "Aptos", "Trebuchet MS", sans-serif;
        letter-spacing: .55px;
        text-transform: uppercase;
      }
      .tab[data-active="true"] {
        color: #eff7f1;
        background: rgba(255,255,255,.1);
        box-shadow: inset 0 0 0 1px rgba(255,255,255,.08);
      }
      #active-command {
        max-height: 76px;
        margin: 0 0 10px;
        overflow: auto;
        padding: 8px 9px;
        border: 1px solid rgba(117,217,168,.15);
        border-radius: 9px;
        color: #98aaa1;
        background: #101a16;
        font: 10px/1.45 Consolas, "Courier New", monospace;
        overflow-wrap: anywhere;
        white-space: pre-wrap;
      }
      #active-command[data-active="true"] { color: #c9f4dc; }
      #state {
        margin-bottom: 6px;
        color: #75d9a8;
        font-size: 10px;
        font-weight: 850;
        letter-spacing: 1px;
        text-transform: uppercase;
      }
      #message {
        min-height: 36px;
        max-height: 76px;
        overflow: auto;
        color: #f3f7f4;
        font-size: 12px;
        overflow-wrap: anywhere;
      }
      .actions {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 8px;
        margin-top: 11px;
      }
      .action {
        min-height: 31px;
        padding: 6px 10px;
        cursor: pointer;
        border: 1px solid rgba(255,255,255,.13);
        border-radius: 9px;
        color: #e8f2ed;
        background: rgba(255,255,255,.07);
        font: 800 10px/1 "Aptos", "Trebuchet MS", sans-serif;
        letter-spacing: .45px;
        text-transform: uppercase;
        transition: transform 120ms ease, background 120ms ease, border-color 120ms ease;
      }
      .action:hover:not(:disabled) { transform: translateY(-1px); }
      .action:disabled { cursor: default; opacity: .38; }
      #connect:not(:disabled) {
        border-color: rgba(99,206,155,.4);
        color: #17231e;
        background: #75d9a8;
      }
      #stop:not(:disabled) {
        border-color: rgba(239,113,95,.38);
        color: #ffc1b7;
        background: rgba(239,113,95,.12);
      }
      .footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        margin-top: 10px;
        padding-top: 9px;
        border-top: 1px solid rgba(255,255,255,.09);
        color: #8fa199;
        font-size: 9px;
      }
      #count { color: #b5c2bc; font-weight: 700; }
      .history-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        margin-bottom: 9px;
        color: #c8d5ce;
        font-size: 10px;
        font-weight: 800;
        letter-spacing: .45px;
        text-transform: uppercase;
      }
      #history-refresh {
        cursor: pointer;
        border: 0;
        color: #75d9a8;
        background: transparent;
        font: 800 9px/1 "Aptos", "Trebuchet MS", sans-serif;
        text-transform: uppercase;
      }
      #history-list {
        max-height: min(430px, calc(100vh - 190px));
        overflow: auto;
        color: #91a39a;
      }
      .history-item {
        margin-bottom: 6px;
        overflow: hidden;
        border: 1px solid rgba(255,255,255,.09);
        border-radius: 9px;
        background: rgba(255,255,255,.035);
      }
      .history-item summary {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        padding: 8px 9px;
        cursor: pointer;
        list-style: none;
      }
      .history-item summary::-webkit-details-marker { display: none; }
      .history-item[open] summary { border-bottom: 1px solid rgba(255,255,255,.08); }
      .history-tool {
        overflow: hidden;
        color: #edf6f1;
        font-weight: 800;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .history-meta { flex: 0 0 auto; font-size: 8px; font-weight: 800; text-transform: uppercase; }
      .history-meta.success { color: #75d9a8; }
      .history-meta.failure { color: #ff8d7d; }
      .history-id {
        display: block;
        overflow: hidden;
        padding: 7px 9px 0;
        color: #82958b;
        font: 8px/1.3 Consolas, monospace;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .io-label {
        padding: 8px 9px 4px;
        color: #f1c46f;
        font-size: 8px;
        font-weight: 850;
        letter-spacing: .7px;
        text-transform: uppercase;
      }
      .history-item pre {
        max-height: 190px;
        margin: 0 7px 8px;
        overflow: auto;
        padding: 8px;
        border-radius: 7px;
        color: #c8d5ce;
        background: #101a16;
        font: 9px/1.4 Consolas, "Courier New", monospace;
        white-space: pre-wrap;
        overflow-wrap: anywhere;
      }
      #card[data-state="executing"] .header-dot,
      #card[data-state="background"] .header-dot,
      #card[data-state="detected"] .header-dot,
      #card[data-state="approval"] .header-dot,
      #card[data-state="cooldown"] .header-dot,
      #card[data-state="sending"] .header-dot {
        background: #f1b74d;
        box-shadow: 0 0 0 4px rgba(241,183,77,.13);
        animation: pulse 1s ease-in-out infinite;
      }
      #card[data-state="executing"] #state,
      #card[data-state="background"] #state,
      #card[data-state="detected"] #state,
      #card[data-state="approval"] #state,
      #card[data-state="cooldown"] #state,
      #card[data-state="sending"] #state { color: #f1c46f; }
      #card[data-state="executing"] #active-tool,
      #card[data-state="background"] #active-tool,
      #card[data-state="approval"] #active-tool,
      #card[data-state="cooldown"] #active-tool,
      #card[data-state="sending"] #active-tool { color: #f1c46f; border-color: rgba(241,183,77,.24); }
      #card[data-state="error"] .header-dot {
        background: #ef715f;
        box-shadow: 0 0 0 4px rgba(239,113,95,.14);
      }
      #card[data-state="error"] #state { color: #ff8d7d; }
      #card[data-state="stopped"] .header-dot {
        background: #7f9188;
        box-shadow: 0 0 0 4px rgba(127,145,136,.12);
      }
      #card[data-state="stopped"] #state { color: #aebdb6; }
      #card[data-collapsed="true"] { width: min(250px, calc(100vw - 16px)); }
      #card[data-collapsed="true"] .body,
      #card[data-collapsed="true"] #project { display: none; }
      #card[data-collapsed="true"] #handle { border-bottom: 0; }
      @keyframes pulse { 50% { opacity: .35; transform: scale(.76); } }
    </style>
    <section id="card" data-state="attached" data-view="status" data-collapsed="false" aria-live="polite">
      <header id="handle">
        <span class="mark" aria-hidden="true">L</span>
        <span class="heading">
          <span class="title">Local agent</span>
          <span id="project">Connecting...</span>
        </span>
        <span id="active-tool" title="No active tool call">Idle</span>
        <span class="header-dot" aria-hidden="true"></span>
        <button id="collapse" type="button" aria-label="Collapse local agent status">-</button>
      </header>
      <div class="body">
        <nav class="tabs" aria-label="Local agent views">
          <button id="status-tab" class="tab" data-active="true" type="button">Status</button>
          <button id="history-tab" class="tab" data-active="false" type="button">History</button>
        </nav>
        <section id="status-panel">
          <pre id="active-command" data-active="false">No tool is running.</pre>
          <div id="state">Ready</div>
          <div id="message">Watching for local tool calls.</div>
          <div class="actions" aria-label="Local agent controls">
            <button id="connect" class="action" type="button">Connect</button>
            <button id="stop" class="action" type="button">Stop</button>
          </div>
          <footer class="footer">
            <span id="updated">Updated now</span>
            <span id="count">Tools: 0</span>
          </footer>
        </section>
        <section id="history-panel" hidden>
          <div class="history-head"><span>Past tool calls</span><button id="history-refresh" type="button">Refresh</button></div>
          <div id="history-list">Open this tab to load history.</div>
        </section>
      </div>
    </section>`,document.documentElement.append(t),y=ve(t),!y)return null;let r=await chrome.storage.local.get([`workspace`,`indicatorPosition`,`indicatorCollapsed`,`agentStatus`]);y.project.textContent=`${N()} - ${P(String(r.workspace||``))}`;let i=r.indicatorCollapsed===!0;y.card.dataset.collapsed=String(i),y.collapse.textContent=i?`+`:`-`,y.collapse.setAttribute(`aria-label`,i?`Expand local agent status`:`Collapse local agent status`);let a=r.indicatorPosition;return Number.isFinite(a?.x)&&Number.isFinite(a?.y)&&requestAnimationFrame(()=>be(t,a)),xe(y),je(y),r.agentStatus?Ne(r.agentStatus):L(),y}function Ne(e){y&&(y.card.dataset.state=e.state,y.state.textContent=_e(e.state),y.message.textContent=e.message,y.updated.textContent=`Updated ${new Date(e.ts).toLocaleTimeString()}`,y.count.textContent=`Tools: ${ue}`,E?L():(y.activeTool.textContent=e.tool||`Idle`,y.activeTool.title=e.toolCallId||`No active tool call`,y.command.textContent=e.command||`No tool is running.`,y.command.dataset.active=String(!!e.tool)))}function z(e){let t=0;for(let n=0;n<e.length;n+=1)t=t*31+e.charCodeAt(n)|0;return String(t)}function Pe(){return`call_${crypto.randomUUID()}`}function B(){try{let e=JSON.parse(sessionStorage.getItem(f)||`[]`);return Array.isArray(e)?e.filter(e=>{if(!e||typeof e!=`object`)return!1;let t=e;return typeof t.tool_call_id==`string`&&typeof t.candidate_id==`string`&&t.tool===`run_command`&&typeof t.started_at==`string`}):[]}catch{return[]}}function Fe(e){try{sessionStorage.setItem(f,JSON.stringify(e))}catch{}}function Ie(e){Fe([...B().filter(t=>t.tool_call_id!==e.tool_call_id),e])}function V(e){Fe(B().filter(t=>t.tool_call_id!==e))}function Le(){for(let e of B())g.add(e.candidate_id)}function H(e){return z(`tool_call:${JSON.stringify({name:e.name,arguments:e.arguments||{}})}`)}function U(e){let t=e.trim(),n=t.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);return n?n[1].trim():t}function Re(e){let t=U(e),n=t.search(/[{\[]/);if(n===-1)return t;let r=0,i=!1,a=!1;for(let e=n;e<t.length;e+=1){let o=t[e];if(i){if(a){a=!1;continue}if(o===`\\`){a=!0;continue}o===`"`&&(i=!1);continue}if(o===`"`){i=!0;continue}if((o===`{`||o===`[`)&&(r+=1),(o===`}`||o===`]`)&&--r,r===0)return t.slice(n,e+1)}return t}function W(e){if(e==null)return{};if(typeof e!=`object`||Array.isArray(e))throw Error(`Tool arguments must be a JSON object.`);return e}function ze(e,t){let n=[];for(let r of t){let t=RegExp(`"${r}"\\s*:\\s*"`,`g`);for(let i of e.matchAll(t))i.index!=null&&n.push({key:r,keyStart:i.index,valueStart:i.index+i[0].length})}return n.sort((e,t)=>e.keyStart-t.keyStart)}function Be(e){let t=``;for(let n=0;n<e.length;n+=1){let r=e[n];if(r!==`\\`||n+1>=e.length){t+=r;continue}let i=e[n+1],a={'"':`"`,"\\":`\\`,"/":`/`,b:`\b`,f:`\f`,n:`
`,r:`\r`,t:`	`};if(Object.hasOwn(a,i)){t+=a[i],n+=1;continue}if(i===`u`){let r=e.slice(n+2,n+6);if(/^[0-9a-f]{4}$/i.test(r)){t+=String.fromCharCode(Number.parseInt(r,16)),n+=5;continue}}t+=`\\${i}`,n+=1}return t}function Ve(e,t,n){let r=e.slice(t.valueStart,n.keyStart),i=/"\s*,\s*$/.exec(r);if(!i)throw Error(`Could not recover the ${t.key} field boundary.`);return Be(r.slice(0,i.index))}function He(e,t){let n=e.slice(t.valueStart).trimEnd(),r=/"\s*}\s*}\s*$/.exec(n);if(!r)throw Error(`Could not recover the ${t.key} field boundary.`);return Be(n.slice(0,r.index))}function Ue(e){let t=U(e).trim(),n=/"name"\s*:\s*"([A-Za-z_][\w-]*)"/.exec(t)?.[1];if(n!==`edit_file`&&n!==`write_file`)return null;let r=ze(t,[`path`])[0];if(!r)return null;if(n===`write_file`){let e=ze(t,[`content`]).at(-1);return!e||e.keyStart<=r.keyStart?null:{name:n,arguments:{path:Ve(t,r,e),content:He(t,e)}}}let i=ze(t,[`old_text`,`old_content`]).find(e=>e.keyStart>r.keyStart),a=ze(t,[`new_text`,`new_content`]).filter(e=>e.keyStart>(i?.keyStart??-1)).at(-1);return!i||!a?null:{name:n,arguments:{path:Ve(t,r,i),old_text:Ve(t,i,a),new_text:He(t,a)}}}function We(e){let t;try{t=JSON.parse(Re(e))}catch(n){let r=Ue(e);if(!r)throw n;t=r}if(!t||typeof t.name!=`string`)throw Error(`Tool payload must contain a string "name".`);return{name:t.name,arguments:W(t.arguments)}}function Ge(e){if(!he())return null;let t;try{t=JSON.parse(U(e))}catch{try{let n=Ue(e);if(!n)return null;t=n}catch{return null}}return!t||typeof t!=`object`||Array.isArray(t)||Object.keys(t).sort().join(`,`)!==`arguments,name`||typeof t.name!=`string`||!re.has(t.name)?null:{name:t.name,arguments:W(t.arguments)}}function Ke(e){let t=null;try{t=Ge(e)}catch{}if(t)return t;let n=Xe(e);for(let e=n.length-1;e>=0;--e){let{payload:t,rawPayload:r}=n[e];try{return We(t)}catch{try{return We(r)}catch{}}}return null}function qe(){let e=location.hostname===`chat.deepseek.com`?r:location.hostname===`chat.z.ai`?i:void 0;e&&(document.addEventListener(a,e=>{let t=e.detail;if(t===`started`){D+=1,j&&(j.streamStarted=!0),S&&G(`generating`,j?`${N()} is streaming API completion ${j.id}.`:`${N()} is generating a response. Local actions are paused.`);return}if(t===`finished`){if(D=Math.max(0,D-1),j?.streamStarted){Pt();return}D===0&&(S&&G(`waiting`,`${N()} finished responding. Checking for a local tool call.`),$())}}),document.addEventListener(o,e=>{let t=e.detail;!j?.streamStarted||typeof t!=`string`||!t||(j.content+=t,!j.bufferProviderDeltas&&(j.sequence+=1,Z({type:`completion.delta`,request_id:j.id,sequence:j.sequence,delta:t})))}),document.addEventListener(e,e=>{if(!S)return;let t=e.detail;if(typeof t!=`string`)return;if(j?.streamStarted){j.finalAnswer=t;return}let n=Ke(t);if(!n)return;let r=H(n),i=`stream:${++fe}:${r}`;_.set(i,n),$()}))}function Je(e){return W(JSON.parse(Re(e)))}function Ye(e,t,n){let r=t;for(;r<n&&/\s/.test(e[r]);)r+=1;if(e.startsWith("```",r))for(r+=3,e.slice(r,r+4).toLowerCase()===`json`&&(r+=4);r<n&&/\s/.test(e[r]);)r+=1;return e[r]===`{`||e[r]===`[`?r:-1}function Xe(t){let n=[],r=t.toLowerCase(),i=0;for(;i<t.length;){let a=r.indexOf(`<tool_call>`,i);if(a===-1)break;let o=a+11,s=r.indexOf(e,o);if(s===-1)break;let c=Ye(t,o,s);if(c===-1){i=s+12;continue}let l=t.slice(c,s).replace(/```\s*$/i,``).trim(),u=[],d=!1,f=!1,p=!1,m=-1,h=-1;for(let n=c;n<t.length;n+=1){let i=t[n];if(d){if(f){f=!1;continue}if(i===`\\`){f=!0;continue}i===`"`&&(d=!1);continue}if(r.startsWith(e,n)){h=n;break}if(i===`"`){d=!0;continue}if(i===`{`&&u.push(`}`),i===`[`&&u.push(`]`),i===`}`||i===`]`){if(u.pop()!==i){p=!0,h=r.indexOf(e,n);break}if(!u.length){m=n+1,h=r.indexOf(e,m);break}}}if(h===-1)break;if(m!==-1)n.push({payload:t.slice(c,m),rawPayload:l,repaired:!1});else{let e=!p&&!d&&u.length>0&&u.length<=4,r=e?[...u].reverse().join(``):``,i=t.slice(c,h).trim();e&&(i=i.replace(/```\s*$/i,``).trimEnd(),i=i.replace(/[),;]+$/,``).trimEnd()),n.push({payload:i+r,rawPayload:l,repaired:e})}i=h+12}return n}async function G(e,t){let n={state:e,message:t,url:location.href,ts:Date.now(),tool:E?.name,toolCallId:E?.callId,command:E?.command};await Me(),Ne(n),await chrome.storage.local.set({agentStatus:n})}async function K(e){let t=await e.json();if(!e.ok)throw Error(String(t.error||`Daemon returned status ${e.status}.`));return t}function Ze(e){let t=e instanceof Error?e.message:String(e);return/extension context (?:has been )?invalidated|context invalidated/i.test(t)}function Qe(){I(!1),Ne({state:`error`,message:`The extension was updated. Reloading this chat tab to attach the new version...`,url:location.href,ts:Date.now()}),window.setTimeout(()=>location.reload(),750)}async function $e(){if(!(S||w)){w=!0,F();try{await G(`connecting`,`Connecting with the saved token and project...`);let e=await chrome.storage.local.get([`token`,`workspace`]),t=String(e.token||``).trim(),n=String(e.workspace||``).trim();if(!t||!n)throw Error(`Open the extension popup once to save a pairing token and project path.`);let r=await K(await fetch(`http://127.0.0.1:43121/connect`,{method:`POST`,headers:{"content-type":`application/json`},body:JSON.stringify({token:t})}));if(r.ok!==!0)throw Error(String(r.error||`Connection failed.`));let i=await K(await fetch(`http://127.0.0.1:43121/workspace`,{method:`POST`,headers:{"content-type":`application/json`,authorization:`Bearer ${t}`},body:JSON.stringify({path:n})}));if(i.ok!==!0)throw Error(String(i.error||`Workspace setup failed.`));let a=String(i.workspace||n);Ce(!1),T=!0,I(!0),le=0,await chrome.storage.local.set({workspace:a,connectedWorkspace:a}),y&&(y.project.textContent=`${N()} - ${P(a)}`),await G(`waiting`,`Connected to ${P(a)}. Waiting for a local tool call.`),Le(),Qt(),Q(),$()}catch(e){if(Ze(e)){Qe();return}I(!1),await G(`error`,`Connection failed: ${e.message}`)}finally{w=!1,F()}}}async function et(){if(!S&&!T||w)return;Ce(!0),T=!1,I(!1),yt(),_.clear(),v.clear(),x=!1,b=!1,le=0,R();let e=q();e&&J(e).includes(`<tool_result>`)&&st(e,``),await G(`stopped`,`Stopped on this tab. Connect to resume local tools.`)}function tt(e){return!!(e.offsetWidth||e.offsetHeight||e.getClientRects().length)}function nt(e){let t=e;return{edits:t?.edits===!0,deletes:t?.deletes===!0,shell:t?.shell===!0}}async function rt(){let e=await chrome.storage.local.get([`approvalSettings`,`workspace`]),t=e.approvalSettings;return t?.scope===`global`?nt(t.global):nt(t?.projects?.[String(e.workspace||``)])}function it(e){return e.name===`run_command`?String(e.arguments?.command||``):String(e.arguments?.path||``)}async function at(e,t){let n=C,r=()=>S&&n===C;for(;r();){let n;try{n=await fetch(`http://127.0.0.1:43121/tool/${encodeURIComponent(e)}`,{headers:{authorization:`Bearer ${t}`}})}catch{await G(`background`,`run_command ${e} is still pending. The daemon is unavailable; retrying in ${p/1e3}s.`),await new Promise(e=>setTimeout(e,p));continue}let r=await K(n);if(r.pending!==!0)return r;let i=Date.parse(String(r.started_at||``));await G(`background`,`run_command ${e} is running in the background (${Number.isFinite(i)?Math.max(0,Math.floor((Date.now()-i)/1e3)):0}s). Waiting for completion.`),await new Promise(e=>setTimeout(e,p))}throw Error(`Local agent stopped while ${e} is still running in the background.`)}async function ot(e,t,n){let{token:r}=await chrome.storage.local.get(`token`);if(!r)throw Error(`Open the extension popup and pair with the local daemon first.`);let i=await rt();if(ie.has(e.name)&&!i.edits||ae.has(e.name)&&!i.deletes||oe.has(e.name)&&!i.shell){if(await G(`approval`,`Waiting for approval to run ${e.name} (${t}).`),!confirm(`${N()} requests local tool: ${e.name}\n${it(e)}\n\nAllow?`))return{success:!1,pending:!1,tool_call_id:t,error:`User denied tool call`};await G(`executing`,`${e.name} approved (${t}). Running locally.`)}let a=await K(await fetch(`http://127.0.0.1:43121/tool`,{method:`POST`,headers:{"content-type":`application/json`,authorization:`Bearer ${r}`},body:JSON.stringify({name:e.name,arguments:e.arguments||{},tool_call_id:t})}));return e.name===`run_command`&&a.pending===!0?(Ie({tool_call_id:t,candidate_id:n,tool:`run_command`,started_at:String(a.started_at||new Date().toISOString()),command:we(e)}),at(t,String(r))):a}function q(){return[...document.querySelectorAll(`textarea,[contenteditable="true"],[contenteditable="plaintext-only"],[role="textbox"]`)].filter(e=>{if(!tt(e)||e.getAttribute(`aria-hidden`)===`true`||e.getAttribute(`aria-disabled`)===`true`||e instanceof HTMLTextAreaElement&&e.disabled||e instanceof HTMLInputElement&&e.disabled||e instanceof HTMLInputElement&&e.type===`search`)return!1;let t=`${e.getAttribute(`aria-label`)||``} ${e.getAttribute(`placeholder`)||``}`;return!/search|filter/i.test(t)}).sort((e,t)=>{let n=e=>{let t=`${e.getAttribute(`aria-label`)||``} ${e.getAttribute(`placeholder`)||``}`;return(/message|ask|prompt|qwen|deepseek|glm/i.test(t)?5e3:0)+(e instanceof HTMLTextAreaElement||e.isContentEditable?1e4:0)+e.getBoundingClientRect().bottom};return n(e)-n(t)}).at(-1)||null}function st(e,t){if(e instanceof HTMLTextAreaElement||e instanceof HTMLInputElement){let n=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;(Object.getOwnPropertyDescriptor(n,`value`)?.set)?.call(e,t),e.dispatchEvent(new Event(`input`,{bubbles:!0}));return}e.focus(),document.execCommand(`selectAll`,!1),document.execCommand(`insertText`,!1,t)||(e.textContent=t),e.dispatchEvent(new InputEvent(`input`,{bubbles:!0,inputType:`insertText`,data:t}))}function J(e){return e instanceof HTMLTextAreaElement||e instanceof HTMLInputElement?e.value:e.innerText||e.textContent||``}function ct(){let e=q();return!!(e&&J(e).includes(`<tool_result>`))}function lt(){return[...document.querySelectorAll(`button,[role="button"]`)].find(e=>{if(!tt(e))return!1;let t=ft(e).trim();return/^(?:(?:stop|cancel)\s*)+$/i.test(t)||/\b(stop|cancel)\s+(generating|generation|response)\b/i.test(t)})||null}function ut(){return!!lt()}function Y(){return D>0||ut()}async function X(e=C){let t=!1;for(;S&&e===C&&Y();)t||(t=!0,await G(`generating`,`${N()} is still generating. The pending local-agent message will wait.`)),await new Promise(e=>setTimeout(e,250));if(!S||e!==C)throw Error(`Local agent stopped while waiting for the AI response to finish.`)}function dt(e){return!(!tt(e)||e.getAttribute(`aria-disabled`)===`true`||e instanceof HTMLButtonElement&&e.disabled)}function ft(e){return[e.getAttribute(`aria-label`),e.getAttribute(`data-testid`),e.getAttribute(`data-test-id`),e.getAttribute(`title`),e.textContent].filter(Boolean).join(` `)}function pt(e){let t=e.parentElement;for(let e=0;t&&e<7;e+=1,t=t.parentElement){let n=[...t.querySelectorAll(`button,[role="button"]`)].filter(dt),r=n.find(e=>/\b(send|submit)\b/i.test(ft(e)));if(r)return r;let i=n.filter(e=>!/attach|upload|image|voice|microphone|clear|stop/i.test(ft(e)));if(e>=2&&i.length)return i.at(-1)||null}return null}function mt(e){e.focus();let t={key:`Enter`,code:`Enter`,keyCode:13,which:13,bubbles:!0,cancelable:!0};e.dispatchEvent(new KeyboardEvent(`keydown`,t)),e.dispatchEvent(new KeyboardEvent(`keyup`,t))}function ht(){try{let e=sessionStorage.getItem(l);if(e)return e;let t=`tab_${crypto.randomUUID()}`;return sessionStorage.setItem(l,t),t}catch{return`tab_${crypto.randomUUID()}`}}function Z(e){if(O?.readyState!==WebSocket.OPEN)return!1;try{return O.send(JSON.stringify(e)),!0}catch{return!1}}function gt(){k&&window.clearTimeout(k),A&&window.clearInterval(A),k=0,A=0}function _t(){if(!S||!me()||k)return;let e=Math.min(u,500*2**pe);pe+=1,k=window.setTimeout(()=>{k=0,Q()},e)}function vt(e=`Completion bridge disconnected.`){let t=j;t&&(j=null,lt()?.click(),Nt(),S&&G(`error`,`${e} Request ${t.id} was cancelled.`))}function yt(){gt();let e=O;O=null,e&&e.readyState<WebSocket.CLOSING&&e.close(1e3,`Local agent stopped`),vt(`Completion bridge closed.`)}function bt(e){return typeof e.content==`string`?e.content:Array.isArray(e.content)?e.content.filter(e=>e.type===`text`&&typeof e.text==`string`).map(e=>e.text).join(`
`):``}function xt(e){let t=[],n=bt(e);return n&&t.push(n),e.tool_calls?.length&&t.push(`[ASSISTANT_TOOL_CALLS]\n${JSON.stringify(e.tool_calls)}`),t.join(`

`)}function St(e){return typeof e==`object`?e.function.name:void 0}function Ct(e,t){return e.length>0&&t!==`none`}function wt(e,t){if(!e.length)return``;if(t===`none`)return`[OPENAI_FUNCTION_TOOL_PROTOCOL_V1]
Do not call any function for this reply. Respond with normal assistant text.`;let n=St(t),r=n?`You MUST call the function named ${JSON.stringify(n)}.`:t===`required`?`You MUST call one available function.`:`Call one available function whenever the task requires external action or information. Otherwise answer normally.`,i=e.map(e=>e.function);return`[OPENAI_FUNCTION_TOOL_PROTOCOL_V1]
MANDATORY FUNCTION CONTROL FOR THIS REPLY
- Never invoke provider-native tools or merely describe a function action.
- The available functions below belong to the API client. To call one, emit literal assistant text for the bridge to convert.
- ${r}
- A function call response must contain exactly one envelope and no other text, Markdown, or explanation.
- Use exactly: <tool_call>{"name":"FUNCTION_NAME","arguments":{}}</tool_call>
- Emit strict JSON. The arguments value must be an object matching the selected function's parameters.
- After emitting one call, stop and wait for the next API request containing its result.
- Never invent function results.

AVAILABLE FUNCTIONS
${JSON.stringify(i)}`}function Tt(e,t,n){let r=e.map(e=>({role:e.role.toUpperCase(),toolCallId:e.tool_call_id,content:xt(e)})).filter(e=>e.content.trim()),i=wt(t,n);return!i&&r.length===1&&r[0].role===`USER`?r[0].content:[`Continue the conversation below and answer the final user message. Treat SYSTEM and DEVELOPER entries as instructions.`,``,...r.flatMap(e=>[`[${e.role}${e.toolCallId?` tool_call_id=${e.toolCallId}`:``}]`,e.content,``]),i].join(`
`).trimEnd()}async function Et(e,t,n){let r=Date.now()+n;for(;Date.now()<r;){if(Y()||J(e).trim()!==t.trim())return!0;await new Promise(e=>setTimeout(e,100))}return!1}async function Dt(e){let t=q();if(!t)throw Error(`${N()} composer was not found.`);st(t,e),b=!0;try{if(mt(t),await Et(t,e,800))return;let n=pt(t);if(n&&(n.click(),await Et(t,e,800)))return;let r=t.closest(`form`);if(r&&(r.requestSubmit(),await Et(t,e,800)))return}finally{b=!1}throw Error(`Could not submit the completion prompt through the ${N()} UI.`)}async function Ot(e){let t=Date.now()+3e4;for(;Date.now()<t;){if(j?.id!==e||j.streamStarted)return;await new Promise(e=>setTimeout(e,100))}throw Error(`${N()} did not start a completion stream within 30 seconds.`)}async function kt(e){let t=String(e.request_id||``),n=Array.isArray(e.messages)?e.messages:[],r=Array.isArray(e.tools)?e.tools:[],i=e.tool_choice||`auto`;if(!(!t||!n.length)){if(!S||j||E||Y()||M||ct()){Z({type:`completion.error`,request_id:t,error:`${N()} tab is busy with another local or provider operation.`});return}j={id:t,model:String(e.model||`${me()}-web`),sequence:-1,content:``,finalAnswer:``,streamStarted:!1,tools:r,toolChoice:i,bufferProviderDeltas:Ct(r,i)},Z({type:`completion.accepted`,request_id:t});try{let e=Tt(n,r,i);if(!e.trim())throw Error(`The completion request does not contain any supported text content.`);if(!await Bt(`API request`,await Rt(),()=>j?.id===t)){if(j?.id!==t)return;throw Error(`Local agent stopped during the API submission cooldown.`)}await G(`sending`,`Submitting API completion ${t} to ${N()}.`),await Dt(e),await Ot(t)}catch(e){if(j?.id!==t)return;j=null,Z({type:`completion.error`,request_id:t,error:e.message}),await G(`error`,`API completion ${t} failed: ${e.message}`)}}}function At(e){let t=Ke(e);if(t)return t;try{let t=JSON.parse(U(e));return!t||typeof t!=`object`||typeof t.name!=`string`?null:{name:t.name,arguments:W(t.arguments)}}catch{return null}}function jt(e){return e===`required`||typeof e==`object`}async function Mt(e,t){j?.id===e.id&&(j=null,Z({type:`completion.error`,request_id:e.id,error:t}),S&&await G(`error`,`API completion ${e.id} failed: ${t}`))}async function Nt(){if(M){for(;M;)await new Promise(e=>setTimeout(e,50));return}M=!0;try{await new Promise(e=>setTimeout(e,500));for(let e of Xt())g.add(e.id),_.delete(e.id)}finally{M=!1}}async function Pt(){let e=j;if(!e)return;let t=e.finalAnswer||e.content,n=At(t);if(n&&v.add(H(n)),await Nt(),j?.id===e.id){if(n&&Ct(e.tools,e.toolChoice)){let t=e.tools.find(e=>e.function.name===n.name),r=St(e.toolChoice);if(!t){await Mt(e,`Provider selected unavailable function ${n.name}.`);return}if(r&&r!==n.name){await Mt(e,`Provider selected ${n.name}, but tool_choice requires ${r}.`);return}let i={id:Pe(),type:`function`,function:{name:n.name,arguments:JSON.stringify(n.arguments)}};j=null,Z({type:`completion.completed`,request_id:e.id,content:null,tool_calls:[i],finish_reason:`tool_calls`}),S&&await G(`waiting`,`API completion ${e.id} requested ${n.name}. Waiting for the API client.`);return}if(jt(e.toolChoice)){await Mt(e,`Provider did not return the required function call.`);return}j=null,Z({type:`completion.completed`,request_id:e.id,content:t,finish_reason:`stop`}),S&&await G(`waiting`,`API completion ${e.id} finished. Waiting for a local tool call.`)}}function Ft(e){let t;try{t=JSON.parse(String(e.data))}catch{return}t.type===`completion.request`?kt(t):t.type===`completion.cancel`&&t.request_id===j?.id&&vt(`API client cancelled the completion.`)}async function Q(){let e=me();if(!S||!e||O&&O.readyState<=WebSocket.OPEN)return;let{token:t}=await chrome.storage.local.get(`token`),n=String(t||``).trim();if(!n||!S)return;gt();let r;try{r=new WebSocket(s,[c,`token.${n}`])}catch{_t();return}O=r,r.addEventListener(`open`,()=>{O===r&&(pe=0,Z({type:`bridge.register`,client_id:ht(),provider:e,url:location.href}),A=window.setInterval(()=>{Z({type:`bridge.ping`,ts:Date.now()})},2e4))}),r.addEventListener(`message`,Ft),r.addEventListener(`close`,()=>{O===r&&(O=null,A&&window.clearInterval(A),A=0,vt(),_t())})}async function It(e,t){if(!T||b||x)return;let n=C,r=J(e);if(!r.trim()||r.includes(m)){t();return}x=!0;try{if(st(e,ge(r)),await G(`waiting`,`${N()} tool instructions reinforced for this message.`).catch(()=>void 0),await new Promise(e=>setTimeout(e,150)),!T||n!==C)return;x=!1,b=!0,t()}finally{x=!1,window.setTimeout(()=>{b=!1},0)}}function Lt(){he()&&(document.addEventListener(`keydown`,e=>{if(e.key!==`Enter`||e.shiftKey||e.ctrlKey||e.altKey||e.metaKey||e.isComposing||!T)return;let t=q(),n=e.target;if(!(!t||!n||n!==t&&!t.contains(n))){if(!b&&(Y()||j||M)){e.preventDefault(),e.stopImmediatePropagation(),G(`generating`,`Wait for ${N()} to finish before sending another message.`);return}if(!b){if(x){e.preventDefault(),e.stopImmediatePropagation();return}!J(t).trim()||J(t).includes(m)||(e.preventDefault(),e.stopImmediatePropagation(),It(t,()=>mt(t)))}}},!0),document.addEventListener(`click`,e=>{if(!T)return;let t=q(),n=e.target;if(!t||!n)return;let r=pt(t);if(!(!r||n!==r&&!r.contains(n))){if(!b&&(Y()||j||M)){e.preventDefault(),e.stopImmediatePropagation(),G(`generating`,`Wait for ${N()} to finish before sending another message.`);return}if(!b){if(x){e.preventDefault(),e.stopImmediatePropagation();return}!J(t).trim()||J(t).includes(m)||(e.preventDefault(),e.stopImmediatePropagation(),It(t,()=>r.click()))}}},!0),document.addEventListener(`submit`,e=>{if(!T)return;let t=q(),n=e.target;if(!(!t||t.closest(`form`)!==n)){if(!b&&(Y()||j||M)){e.preventDefault(),e.stopImmediatePropagation(),G(`generating`,`Wait for ${N()} to finish before sending another message.`);return}if(!b){if(x){e.preventDefault(),e.stopImmediatePropagation();return}!J(t).trim()||J(t).includes(m)||(e.preventDefault(),e.stopImmediatePropagation(),It(t,()=>n.requestSubmit()))}}},!0))}async function Rt(){let{resultDelayMs:e}=await chrome.storage.local.get(`resultDelayMs`),t=Number(e);return Number.isFinite(t)?Math.min(ne,Math.max(te,t)):ee}function zt(e,t=Date.now()){let n=Math.max(t+e,le);return le=n+e,n}async function Bt(e,t,n=()=>!0){let r=C,i=()=>S&&r===C,a=zt(t);for(;a>Date.now();){if(!i()||!n())return!1;let t=a-Date.now(),r=Math.max(1,Math.ceil(t/1e3));await G(`cooldown`,`${e} ready. Sending to ${N()} in ${r} second${r===1?``:`s`}.`),await new Promise(e=>setTimeout(e,Math.min(1e3,t)))}return i()&&n()}async function Vt(e){if(!S)return!1;let t=C,n=()=>S&&t===C;if(!await Bt(`Tool result`,e)||!n())return!1;await X(t),await G(`sending`,`Sending the tool result to ${N()} now.`);let r=q();if(!r||(mt(r),await new Promise(e=>setTimeout(e,450)),!n()))return!1;if(Y()||!ct())return!0;await X(t),r=q();let i=r&&pt(r);if(i){if(i.click(),await new Promise(e=>setTimeout(e,450)),!n())return!1;if(Y()||!ct())return!0}await X(t),r=q();let a=r?.closest(`form`);return a&&(a.requestSubmit(),await new Promise(e=>setTimeout(e,450))),!ct()}async function Ht(e){if(!S)throw Error(`Local agent is stopped on this tab.`);await X();let t=ge(`<tool_result>\n${JSON.stringify(e)}\n</tool_result>\nContinue the original task using the required local-agent protocol.`),n=q();if(!n)throw Error(`${N()} composer not found on this tab.`);if(st(n,t),!await Vt(await Rt()))throw Error(`Could not auto-submit the tool result. ${N()} UI selectors may need updating.`)}function Ut(e){return!!e.closest([`[data-message-author-role="user" i]`,`[data-role="user" i]`,`[data-author="user" i]`,`[data-testid*="user-message" i]`,`[class~="user-message" i]`].join(`,`))}function Wt(e){return e.closest([`[data-message-id]`,`[data-msg-id]`,`[data-message-author-role="assistant" i]`,`[data-role="assistant" i]`,`[data-author="assistant" i]`,`[data-testid*="assistant-message" i]`,`[class~="assistant-message" i]`].join(`,`))||e}function Gt(e){let t=[],n=e;for(;n?.parentElement&&t.length<18;){let e=n.parentElement.children;t.push(Array.prototype.indexOf.call(e,n)),n=n.parentElement}return t.reverse().join(`.`)}function Kt(e){let t=Wt(e);for(let e of[`data-message-id`,`data-msg-id`]){let n=t.getAttribute(e);if(n)return`${e}:${n}`}return`path:${Gt(t)}`}function qt(e){let t=new Map;for(let n of e){let e=t.get(n.baseId)||[];e.push(n),t.set(n.baseId,e)}let n=[];for(let e of t.values()){let t=new Map;for(let n of e)t.set(n.element,n);let r=[...t.values()];n.push(...r.filter(e=>!r.some(t=>t.element!==e.element&&e.element.contains(t.element))))}let r=n.sort((e,t)=>e.order-t.order).at(-1);if(!r)return;let i=z(`occurrence:${r.baseId}:${Kt(r.element)}`);if(v.has(r.baseId)){v.delete(r.baseId),g.add(i);return}if(!g.has(i))return{id:i,baseId:r.baseId,source:`dom`,...r.value}}function Jt(){let e=[],t=document.querySelectorAll(`pre,code`),n=0;for(let r of t){n+=1;let t=r;if(t.closest(`form,textarea,[role="textbox"],[contenteditable]:not([contenteditable="false"])`)||Ut(t))continue;let i=(t.innerText||t.textContent||``).trim();if(!i)continue;let a=Ge(i);a&&e.push({baseId:H(a),element:t,order:n,value:{call:a}})}return qt(e)}function Yt(e){return/["']name["']\s*:\s*["']([A-Za-z_][\w-]*)["']/i.exec(e)?.[1]}function Xt(){let e=[..._.entries()].at(-1);if(e){let[t,n]=e;return g.has(t)?[]:[{id:t,baseId:H(n),source:`stream`,call:n}]}let n=Jt();if(n)return[n];let r=[],i=document.querySelectorAll(`pre,code,article,div,p,span,tool_call,tool-call`),a=0;for(let e of i){a+=1;let n=e;if(n.closest(`form,textarea,[role="textbox"],[contenteditable]:not([contenteditable="false"])`)||Ut(n))continue;let i=(n.innerText||n.textContent||``).trim();if(!i)continue;let o=Ge(i);o&&r.push({baseId:H(o),element:n,order:a,value:{call:o}});for(let e of Xe(i)){let{payload:t,rawPayload:i}=e;try{let o;try{o=We(t)}catch(e){if(i===t)throw e;o=We(i)}r.push({baseId:H(o),element:n,order:a,value:{call:o,repaired:e.repaired}})}catch(e){r.push({baseId:z(`tool_block_error:${i}`),element:n,order:a,value:{toolName:Yt(i),error:`Found <tool_call> markup but could not parse its JSON: ${e.message}`}})}}for(let e of i.matchAll(t)){let t=e[1],i=e[2];try{let e={name:t,arguments:Je(i)};r.push({baseId:H(e),element:n,order:a,value:{call:e}})}catch(e){r.push({baseId:z(`labeled_tool_error:${t}\n${i}`),element:n,order:a,value:{toolName:t,error:`Found "Call Tool" output for ${t} but could not parse Arguments JSON: ${e.message}`}})}}}let o=qt(r);return o?[o]:[]}async function Zt(e,t,n,r=Pe()){if(!S)return;let i=C,a=()=>S&&i===C;try{if(await Ht({tool:e,tool_call_id:r,success:!1,phase:t,error:n,retryable:!0,instruction:t===`parse`?`Retry with exactly one tool call containing valid JSON.`:`Review the error and retry with corrected tool arguments if appropriate.`}),!a())return;R(r),await G(`waiting`,`Reported the ${t} failure for ${e} (${r}) to ${N()}. Waiting for a corrected call.`)}catch(e){if(!a())return;R(r);let t=e.message;await G(`error`,`${n} Could not return this failure to ${N()}: ${t}`),console.error(`[Local AI Agent] Could not return failure to the chat.`,e)}}async function Qt(){if(!S||de)return;let e=B();for(let t of e)g.add(t.candidate_id);if(e.length){de=!0;try{let{token:t}=await chrome.storage.local.get(`token`);if(!t){await G(`error`,`Cannot resume background shell jobs until a pairing token is saved.`);return}for(let n of e){if(!S)return;E={name:n.tool,callId:n.tool_call_id,command:n.command||`> run_command [resumed background job]`},L();let e;try{e=await at(n.tool_call_id,String(t))}catch(e){if(!S)return;let t=e.message;V(n.tool_call_id),R(n.tool_call_id),await Zt(n.tool,`execution`,t,n.tool_call_id);continue}if(!S)return;try{if(await Ht({tool:n.tool,...e}),V(n.tool_call_id),!S)return;R(n.tool_call_id),Ae(),await G(`waiting`,`Finished ${n.tool} (${n.tool_call_id}). Waiting for the next <tool_call>.`)}catch(e){if(!S)return;await G(`error`,`${n.tool} (${n.tool_call_id}) finished, but its result could not be returned to ${N()}: ${e.message}`);return}}}finally{de=!1}}}async function $t(){if(!S||Y()||j||M)return;let e=C,t=()=>S&&e===C,n=Xt();if(n.length)for(let e of n){if(!t())return;let{id:n}=e;if(g.has(n))continue;g.add(n),e.source===`stream`&&v.add(e.baseId),_.delete(n);let r=Pe();if(e.error){if(ue+=1,Te({name:e.toolName||`unknown`},r),await G(`error`,`${e.error} Tool call ID: ${r}.`),!t())return;await Zt(e.toolName||`unknown`,`parse`,e.error,r);continue}let i=e.call;if(!i)continue;ue+=1,Te(i,r);let a=e.repaired?` Recovered missing trailing JSON delimiter.`:``;await G(`executing`,`Tool call triggered: ${i.name} (${r}).${a} Running locally.`);let o;try{o=await ot(i,r,n)}catch(e){if(!t())return;let n=e.message;V(r),await G(`error`,`${i.name} (${r}) failed: ${n}`),await Zt(i.name,`execution`,n,r),console.error(`[Local AI Agent]`,e);continue}if(!t())return;try{if(await Ht({tool:i.name,...o}),V(r),!t())return;R(r),Ae(),await G(`waiting`,`Finished ${i.name} (${r}). Waiting for the next <tool_call>.`)}catch(e){if(!t())return;let n=e.message;await G(`error`,`${i.name} (${r}) finished, but its result could not be returned to ${N()}: ${n}`),console.error(`[Local AI Agent]`,e)}}}function $(){!S||Y()||j||M||ce||(ce=!0,window.setTimeout(()=>{ce=!1,S&&!Y()&&!j&&!M&&$t()},150))}function en(){chrome.storage.onChanged.addListener((e,t)=>{if(t!==`local`)return;let n=e.workspace?.newValue;n&&y&&(y.project.textContent=`${N()} - ${P(String(n))}`),!(!e.token&&!e.workspace&&!e.connectedWorkspace)&&chrome.storage.local.get([`token`,`workspace`,`connectedWorkspace`]).then(async t=>{let n=t.connectedWorkspace||t.workspace;if(!(t.token&&n)){yt(),S&&(I(!1),await G(`stopped`,`Connection settings were removed. Connect after saving them again.`));return}!Se()&&!S?(I(!0),await G(`waiting`,`Connected to ${P(String(n))}. Waiting for a local tool call.`),Le(),Qt(),Q(),$()):S&&e.token&&(yt(),Q())}).catch(()=>void 0)})}async function tn(){if(await Me(),se.__deepseekLocalAgentLoaded){await G(`attached`,`Content script already attached to this tab. Use Connect or Stop here.`);return}se.__deepseekLocalAgentLoaded=!0;let e=await chrome.storage.local.get([`token`,`workspace`,`connectedWorkspace`]),t=e.connectedWorkspace||e.workspace;T=!Se(),I(!!(e.token&&t)&&T),Le(),Lt(),qe(),en(),new MutationObserver(()=>$()).observe(document.documentElement,{subtree:!0,childList:!0,characterData:!0}),S?(await G(`waiting`,`Connected to ${P(String(t))}. Waiting for a local tool call.`),Qt(),Q(),$()):await G(`stopped`,e.token&&t?`Stopped on this tab. Connect to resume local tools.`:`Not connected. Save a token and project in the popup, then connect here.`)}tn();